#!/bin/bash

flag=${1-0}
kubectl create ns sdewan-system
sleep 1
kubectl apply -f nse-composition-ns.yaml
kubectl apply -f passthrough-1.yaml
kubectl apply -f passthrough-2.yaml
kubectl apply -f passthrough-3.yaml
kubectl apply -f firewall-config-file.yaml
kubectl apply -f firewall-nse.yaml
if [ $flag -gt 1 ]; then
	kubectl apply -f nse.yaml
fi

if [ $flag -gt 0 ]; then
	kubectl apply -f clientDeploy.yaml
fi

