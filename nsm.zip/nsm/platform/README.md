# Akraino ICN SDEWAN platform

Akraino ICN SDEWAN platform includes below files/folders:

* crd-ctrlr
includes source code of sdewan controller, CR definition and sample yaml file to define the CR

* cnf
includes source code of sdewan cnf

* test
includes test steps and scripts for an E2E test scenario

* README.md: this file
